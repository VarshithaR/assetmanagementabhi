package com.capgemini.asset.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.asset.bean.AssetDetails;
import com.capgemini.asset.dao.AdminAssetInformationDatabase;
import com.capgemini.asset.dao.UserAssetInformationDatabase;
import com.capgemini.asset.exception.AssetException;

public class UserAssetInformationDatabaseTest {
	UserAssetInformationDatabase user=new UserAssetInformationDatabase();
    AssetDetails asset= new AssetDetails();

	@Test
	public void testCheckAssetID() throws AssetException {
		asset.setAsset_id(2233);
		assertEquals(1,user.checkAssetID(asset));
	}

	@Test
	public void testRaiseRequest() throws AssetException {
		asset.setAsset_id(2233);
		asset.setEmp_no(10024);
		assertEquals(101,user.raiseRequest(asset));
	}

	@Test
	public void testCheckEmpno() throws AssetException {
		asset.setEmp_no(10024);
		assertEquals(1, user.checkEmpno(asset));
	}

	@Test
	public void testCheckStatus() throws AssetException {
		asset.setAllocation_id(101);
		assertEquals("pending", user.checkStatus(asset));
	}

	@Test
	public void testCheckAlreadyRequest() throws AssetException {
		asset.setEmp_no(101);
		assertEquals(0, user.checkAlreadyRequest(asset));
	}


}
